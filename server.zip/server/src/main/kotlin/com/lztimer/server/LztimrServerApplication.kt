package com.lztimer.server

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class LztimrServerApplication

fun main(args: Array<String>) {
    SpringApplication.run(LztimrServerApplication::class.java, *args)
}
